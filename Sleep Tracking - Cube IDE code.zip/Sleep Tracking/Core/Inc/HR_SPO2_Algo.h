/*
 * HR_SPO2_Algo.h
 *
 *  Created on: Aug 11, 2024
 *      Author: veerg
 */

#ifndef INC_HR_SPO2_ALGO_H_
#define INC_HR_SPO2_ALGO_H_

#include <stdint.h>

#define ST 4      // Sampling time in s. WARNING: if you change ST, then you MUST recalcuate the sum_X2 parameter below!
#define FS 25     // Sampling frequency in Hz.
#define BUFFER_SIZE (FS*ST) // Number of smaples in a single batch
#define FS60 (FS*60)  // Conversion factor for heart rate from bps to bpm
void calculate_heart_rate(uint32_t red_buffer[], uint32_t ir_buffer[], uint32_t* heartrate);

#endif /* INC_HR_SPO2_ALGO_H_ */
