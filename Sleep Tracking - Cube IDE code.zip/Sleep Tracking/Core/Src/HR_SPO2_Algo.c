

#include <stdint.h>
#include "HR_SPO2_Algo.h"

void calculate_heart_rate(uint32_t red_buffer[], uint32_t ir_buffer[], uint32_t* heartrate) {
	/*
	 * Calculates heart rate by looking at the time between peaks in the analog signal produced by the heartrate sensor
	 * To protect against false peaks, it looks for points that are larger than the next 4 points either side
	 * This function compares results from the IR and red light sensors, and if they are within 10% of each other, an average is taken for the final result
	 */
    uint32_t red_peaks[BUFFER_SIZE] = {0}; // Array to store indices of red buffer peaks
    uint32_t ir_peaks[BUFFER_SIZE] = {0};  // Array to store indices of IR buffer peaks
    int red_peak_count = 0;
    int ir_peak_count = 0;

    for (int i = 4; i < BUFFER_SIZE - 4; i++) {
            if (red_buffer[i] > red_buffer[i - 1] && red_buffer[i] > red_buffer[i - 2] &&
                red_buffer[i] > red_buffer[i - 3] && red_buffer[i] > red_buffer[i - 4] &&
                red_buffer[i] > red_buffer[i + 1] && red_buffer[i] > red_buffer[i + 2] &&
                red_buffer[i] > red_buffer[i + 3] && red_buffer[i] > red_buffer[i + 4]) {
                red_peaks[red_peak_count++] = i;
            }
        }

        // Detect peaks in the IR buffer
        for (int i = 4; i < BUFFER_SIZE - 4; i++) {
            if (ir_buffer[i] > ir_buffer[i - 1] && ir_buffer[i] > ir_buffer[i - 2] &&
                ir_buffer[i] > ir_buffer[i - 3] && ir_buffer[i] > ir_buffer[i - 4] &&
                ir_buffer[i] > ir_buffer[i + 1] && ir_buffer[i] > ir_buffer[i + 2] &&
                ir_buffer[i] > ir_buffer[i + 3] && ir_buffer[i] > ir_buffer[i + 4]) {
                ir_peaks[ir_peak_count++] = i;
            }
        }


    // Calculate average R-R interval for red buffer
    float red_avg_rr_interval = 0.0;
    if (red_peak_count > 1) {
        for (int i = 1; i < red_peak_count; i++) {
            int rr_samples = red_peaks[i] - red_peaks[i - 1];
            red_avg_rr_interval += (float)rr_samples / FS;
        }
        red_avg_rr_interval /= (red_peak_count - 1);
    }

    // Calculate average R-R interval for IR buffer
    float ir_avg_rr_interval = 0.0;
    if (ir_peak_count > 1) {
        for (int i = 1; i < ir_peak_count; i++) {
            int rr_samples = ir_peaks[i] - ir_peaks[i - 1];
            ir_avg_rr_interval += (float)rr_samples / FS;
        }
        ir_avg_rr_interval /= (ir_peak_count - 1);
    }

    // Combine the average intervals from both buffers if both have peaks
    if (red_avg_rr_interval / ir_avg_rr_interval > 1.1 || red_avg_rr_interval / ir_avg_rr_interval < 0.909){
    	*heartrate = -1;
    }
    if (red_peak_count > 1 && ir_peak_count > 1) {
        float combined_avg_rr_interval = (red_avg_rr_interval + ir_avg_rr_interval) / 2;
        *heartrate = (int32_t)(60.0 / combined_avg_rr_interval);
    } else if (red_peak_count > 1) {
        // Use only red buffer if IR buffer has insufficient peaks
        *heartrate = (int32_t)(60.0 / red_avg_rr_interval);
    } else if (ir_peak_count > 1) {
        // Use only IR buffer if red buffer has insufficient peaks
        *heartrate = (int32_t)(60.0 / ir_avg_rr_interval);
    } else {
        // If no peaks are detected in either buffer, set heart rate to -1 (error)
        *heartrate = -1;
    }
}


