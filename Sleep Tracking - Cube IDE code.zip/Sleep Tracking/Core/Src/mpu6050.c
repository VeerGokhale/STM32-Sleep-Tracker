/*
 * mpu6050.c
 *
 *  Created on: Jul 21, 2024
 *      Author: veerg
 */

#include "mpu6050.h"
#include <main.h>
#include <stdio.h>
#include <math.h>

extern I2C_HandleTypeDef hi2c2;
/*
 * initialization of the mpu6050 registers
 */
int mpu6050_init(){
uint8_t check, Data;

HAL_StatusTypeDef presence = HAL_I2C_Mem_Read(&hi2c2, MPU_ADDR, WHO_AM_I_REG, 1,&check, 1, 1000);

if (presence != HAL_OK){
	return 1;
}


HAL_StatusTypeDef ret_connect_MPU = HAL_I2C_IsDeviceReady(&hi2c2, MPU_ADDR, 1, 1000);

if (ret_connect_MPU != HAL_OK){
	return 2;
}

uint8_t temp_data = FS_GYRO_500;
HAL_StatusTypeDef  ret_config_gyro= HAL_I2C_Mem_Write(&hi2c2, (DEVICE_ADDRESS <<1) + 0, REG_CONFIG_GYRO, 1, &temp_data, 1, 100); //configuring the gyroscope to have a range of +/-500 deg/s

if (ret_config_gyro != HAL_OK){
	return 3;
}
temp_data = FS_ACC_4G;

HAL_StatusTypeDef ret_config_acc = HAL_I2C_Mem_Write(&hi2c2, (DEVICE_ADDRESS <<1) + 0, REG_CONFIG_ACC, 1, &temp_data, 1, 100); //configuring the accelerometer to have a range of +/-4g

if (ret_config_acc != HAL_OK){
	return 4;
}

temp_data = 0;
HAL_StatusTypeDef ret_config_powertemp = HAL_I2C_Mem_Write(&hi2c2, (DEVICE_ADDRESS <<1) + 0, REG_USER_CTRL, 1, &temp_data, 1, 100);

if (ret_config_powertemp != HAL_OK){
	return 5;
}

return 0;
}

/*
 * reading the mpu6050 registers and converting raw values to appropriate units (deg/s)
 */
void mpu6050_read(float* x_acc_p, float* y_acc_p, float* z_acc_p, int16_t* x_gyro_p, int16_t* y_gyro_p, int16_t* z_gyro_p){

	uint8_t acc_data[6];
	uint8_t gyro_data[6];
	int16_t x_acc_raw = 0;
	int16_t y_acc_raw = 0;
	int16_t z_acc_raw = 0;
	int16_t x_gyro_raw = 0;
	int16_t y_gyro_raw = 0;
	int16_t z_gyro_raw = 0;

	HAL_I2C_Mem_Read(&hi2c2, (DEVICE_ADDRESS <<1) + 0, REG_DATA, 1, acc_data, 6, 100);

	x_acc_raw = (int16_t)(acc_data[0] << 8 | acc_data[1]);
	y_acc_raw = (int16_t)(acc_data[2] << 8 | acc_data[3]);
	z_acc_raw = (int16_t)(acc_data[4] << 8 | acc_data[5]);

	*x_acc_p = (float)x_acc_raw/8192;
	*y_acc_p = (float)y_acc_raw/8192;
	*z_acc_p = (float)z_acc_raw/8192;

	//total_acc = (int16_t) sqrt((double) (x_acc*x_acc + y_acc*y_acc + z_acc*z_acc));

	HAL_I2C_Mem_Read(&hi2c2, MPU_ADDR, REG_GYRO_DATA, 1, gyro_data, 6, 1000);

	x_gyro_raw = (int16_t)(gyro_data[0] << 8 | acc_data[1]);
	y_gyro_raw = (int16_t)(gyro_data[2] << 8 | acc_data[3]);
	z_gyro_raw = (int16_t)(gyro_data[4] << 8 | acc_data[5]);

	*x_gyro_p = x_gyro_raw/65.5;
	*y_gyro_p = y_gyro_raw/65.5;
	*z_gyro_p = z_gyro_raw/65.5;

}

