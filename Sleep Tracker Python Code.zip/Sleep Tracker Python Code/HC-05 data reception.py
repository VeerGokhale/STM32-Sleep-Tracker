# -*- coding: utf-8 -*-
import serial

# Replace 'COM7' with the correct COM port your HC-05 is connected to.
bluetooth_port = 'COM7'  # This is the Outgoing port
baudrate = 9600

try:
    # Set up the serial connection
    ser = serial.Serial(bluetooth_port, baudrate, timeout=1)

    print(f"Listening on {bluetooth_port} at {baudrate} baud rate...")

    while True:
        # Read data from the serial port
        data = ser.readline().decode('utf-8').strip()  # Read a line, decode it and strip any extra whitespace

        if data:
            print(f"Received: {data}")

except serial.SerialException as e:
    print(f"Could not open port {bluetooth_port}: {e}")

except KeyboardInterrupt:
    print("Exiting program")

finally:
    if ser.is_open:
        ser.close()
        print("Serial port closed")
